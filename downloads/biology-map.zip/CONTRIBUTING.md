# Contribute to the workshop

## Start with a conversation

A source, objection, or question is enough to join. No formatted artifact is required to enter the discussion. In the biology room, help check whether the three seeded claims are supported by their primary sources: find evidence, challenge a match, or suggest a better shared question. Shadow assembles the shared answer and preserves each contributor’s credit. An informal reply is participation; accepted research still needs the review described below.

## Join a project

Open its linked project room. Read the brief, artifacts and recent comments. Comment with the task you are taking, your intended artifact and a time or compute limit. A claim is coordination, not exclusive ownership; update the room if you stop.

## Work locally with your agent

Fork this repository, or download the starter packet from the website. Give your chosen agent the project brief, relevant public artifacts and AGENT_GUIDE.md. You control its execution and budget. There is no provider lock-in and no credential upload.

## Return something checkable

Put files in `contributions/<project>/<your-handle>-<short-title>/`. Include `CONTRIBUTION.md` using the template and links to sources. Open a pull request and link the project-room issue. For text-only findings, use the contribution issue form; attach public artifacts or link a repository. Shadow can integrate an accepted issue contribution with attribution.

A contribution needs: what you attempted; what you produced; how to check it; limits and failed attempts; what tools helped; and the prior work you used. Do not paste a long agent conversation in place of a result.

## Review and acceptance

Another person or Shadow checks the output against the project brief. Review may reproduce code, inspect the cited source, or compare against a stated criterion. The review comment records what was checked and what remains uncertain. Agent self-review alone is not an independent review. Reviewers do not run unfamiliar code without inspecting it.

Shadow targets an initial response within one working day. Reviews explicitly distinguish accepted evidence from unchecked claims. Maintainer-authored seeds may be published with a self-check, but keep that label; publication is not independent acceptance. Every accepted result needs a link from `results/README.md`, a review receipt, credit, and a visible next task. Newcomers may submit a short text finding; Shadow handles file formatting when needed.

For a PR, acceptance is a review plus merge. For an issue, acceptance is a review comment plus a linked commit preserving the artifact and credit. A closed issue without an artifact is not an accepted research result. Negative findings can be accepted; unsupported claims cannot.

## Build on a result

Cite the parent artifact path and full commit SHA in your contribution note. State what you changed or challenged. Preserve prior credits. Accepted versions remain available in Git history; use a new contribution directory for a new attempt. The results index links artifacts and their acceptance records.

## Bring a project

Use the project issue form: state a question, why it matters, shareable inputs, a first small task, and how someone else could check the outcome. Shadow helps turn it into a brief. You do not need to arrive with an agent or a finished research plan.

All project rooms and contributions in this repository are public. Share only material you can publish. Participation creates contributor credit, not equity or an obligation to spend money.
